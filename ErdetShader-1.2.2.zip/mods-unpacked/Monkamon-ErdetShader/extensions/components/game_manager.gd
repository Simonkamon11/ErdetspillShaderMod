extends "res://components/game_manager.gd"

var shader_enabled: bool = true
var shader_hue: int = 30
var shader_saturation: float = 0.6
var shader_energy: float = 5.0
var shader_tonemap_mode: int = 3
var shader_posterization_enabled: bool = true
var shader_shadow: float = 0.6
var shader_glow_enabled: bool = true
var shader_hud_enabled: bool = true
var shader_wide_enabled: bool = false

func apply_shader(enabled: bool):
	shader_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shader()

func apply_shader_hue(hue: int):
	shader_hue = hue
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_hue()

func apply_shader_saturation(sat: float):
	shader_saturation = sat
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_saturation()

func apply_shader_energy(nrg: float):
	shader_energy = nrg
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_energy()

func apply_shader_tonemap_mode(idx: int):
	shader_tonemap_mode = idx
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_tonemap_mode()

func apply_shader_posterization(enabled: bool):
	shader_posterization_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_posterization()

func apply_shader_shadow(opt):
	shader_shadow = opt
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shadow()

func apply_shader_glow(enabled):
	shader_glow_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_glow()

func apply_shader_hide_hud(enabled):
	shader_hud_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_hide_hud()

func apply_shader_viewport_size(enabled):
	shader_wide_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_viewport_size()


func shader_reset():
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	
	shader_enabled = true
	shader_mod.apply_shader()
	shader_hue = 30
	shader_mod.apply_hue()
	shader_saturation = 0.6
	shader_mod.apply_saturation()
	shader_energy = 5.0
	shader_mod.apply_energy()
	shader_tonemap_mode = 3
	shader_mod.apply_tonemap_mode()
	shader_posterization_enabled = true
	shader_mod.apply_posterization()
	shader_shadow = 0.6
	shader_mod.apply_shadow()
	shader_glow_enabled = true
	shader_mod.apply_glow()
	shader_hud_enabled = true
	shader_mod.apply_hide_hud()
	shader_wide_enabled = false
	shader_mod.apple_viewport_size()
