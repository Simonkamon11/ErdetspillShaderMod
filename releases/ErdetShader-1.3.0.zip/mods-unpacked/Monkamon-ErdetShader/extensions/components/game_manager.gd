extends "res://components/game_manager.gd"

var shader_enabled: bool = true
var shader_preset: int = 0
var shader_hue: int = 30
var shader_saturation: float = 0.6
var shader_energy: float = 5.0
var shader_tonemap_mode: int = 3
var shader_posterization_enabled: bool = true
var shader_shadow: float = 0.6
var shader_glow_enabled: bool = false
var shader_fog_enabled: bool = true
var shader_volume_fog_enabled: bool = false
var shader_hud_enabled: bool = true
var shader_wide_enabled: bool = false

const SHADER_CONFIG_PATH := "user://erdetshader.cfg"
func _ready() -> void:
	super()
	shader_load()

func apply_shader(enabled: bool):
	shader_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shader()
	shader_save()

func apply_shader_preset(idx: int):
	shader_preset = idx
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	if idx == 0:
		shader_enabled = true
		shader_mod.apply_shader()
		shader_hue = 30
		shader_mod.apply_hue()
		shader_saturation = 0.6
		shader_mod.apply_saturation()
		shader_energy = 5.0
		shader_mod.apply_energy()
		shader_tonemap_mode = 3
		shader_mod.apply_tonemap_mode()
		shader_posterization_enabled = true
		shader_mod.apply_posterization()
		shader_shadow = 0.6
		shader_mod.apply_shadow()
		shader_glow_enabled = false
		shader_mod.apply_glow()
		shader_fog_enabled = true
		shader_mod.apply_fog()
		shader_volume_fog_enabled = true
		shader_mod.apply_volume_fog()
		return
	elif idx == 1:
		shader_enabled = true
		shader_mod.apply_shader()
		shader_hue = 35
		shader_mod.apply_hue()
		shader_saturation = 0.45
		shader_mod.apply_saturation()
		shader_energy = 2.0
		shader_mod.apply_energy()
		shader_tonemap_mode = 3
		shader_mod.apply_tonemap_mode()
		shader_posterization_enabled = false
		shader_mod.apply_posterization()
		shader_shadow = 0.6
		shader_mod.apply_shadow()
		shader_glow_enabled = true
		shader_mod.apply_glow()
		shader_fog_enabled = true
		shader_mod.apply_fog()
		shader_volume_fog_enabled = true
		shader_mod.apply_volume_fog()
	elif idx == 2:
		shader_enabled = true
		shader_mod.apply_shader()
		shader_hue = 25
		shader_mod.apply_hue()
		shader_saturation = 0.6
		shader_mod.apply_saturation()
		shader_energy = 4.0
		shader_mod.apply_energy()
		shader_tonemap_mode = 0
		shader_mod.apply_tonemap_mode()
		shader_posterization_enabled = false
		shader_mod.apply_posterization()
		shader_shadow = 0.9
		shader_mod.apply_shadow()
		shader_glow_enabled = true
		shader_mod.apply_glow()
		shader_fog_enabled = true
		shader_mod.apply_fog()
		shader_volume_fog_enabled = true
		shader_mod.apply_volume_fog()
	elif idx == 3:
		shader_enabled = true
		shader_mod.apply_shader()
		shader_hue = 30
		shader_mod.apply_hue()
		shader_saturation = 0.2
		shader_mod.apply_saturation()
		shader_energy = 5.0
		shader_mod.apply_energy()
		shader_tonemap_mode = 2
		shader_mod.apply_tonemap_mode()
		shader_posterization_enabled = true
		shader_mod.apply_posterization()
		shader_shadow = 0.8
		shader_mod.apply_shadow()
		shader_glow_enabled = false
		shader_mod.apply_glow()
		shader_fog_enabled = false
		shader_mod.apply_fog()
		shader_volume_fog_enabled = false
		shader_mod.apply_volume_fog()
	elif idx == 4:
		shader_enabled = true
		shader_mod.apply_shader()
		shader_hue = 0
		shader_mod.apply_hue()
		shader_saturation = 1.0
		shader_mod.apply_saturation()
		shader_energy = 0.0
		shader_mod.apply_energy()
		shader_tonemap_mode = 3
		shader_mod.apply_tonemap_mode()
		shader_posterization_enabled = false
		shader_mod.apply_posterization()
		shader_shadow = 1.0
		shader_mod.apply_shadow()
		shader_glow_enabled = true
		shader_mod.apply_glow()
		shader_fog_enabled = false
		shader_mod.apply_fog()
		shader_volume_fog_enabled = false
		shader_mod.apply_volume_fog()
	shader_save()

func apply_shader_hue(hue: int):
	shader_hue = hue
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_hue()
	shader_save()

func apply_shader_saturation(sat: float):
	shader_saturation = sat
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_saturation()
	shader_save()

func apply_shader_energy(nrg: float):
	shader_energy = nrg
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_energy()
	shader_save()

func apply_shader_tonemap_mode(idx: int):
	shader_tonemap_mode = idx
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_tonemap_mode()
	shader_save()

func apply_shader_posterization(enabled: bool):
	shader_posterization_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_posterization()
	shader_save()

func apply_shader_shadow(opt: float):
	shader_shadow = opt
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shadow()
	shader_save()

func apply_shader_glow(enabled: bool):
	shader_glow_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_glow()
	shader_save()

func apply_shader_fog(enabled: bool):
	shader_fog_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_fog()
	shader_save()

func apply_shader_volume_fog(enabled: bool):
	shader_volume_fog_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_volume_fog()
	shader_save()

func apply_shader_hide_hud(enabled: bool):
	shader_hud_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_hide_hud()
	shader_save()

func apply_shader_viewport_size(enabled: bool):
	shader_wide_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_viewport_size()
	shader_save()


func shader_reset():
	apply_shader_preset(0)
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_enabled = false
	shader_mod.apply_shader()
	shader_hud_enabled = true
	shader_mod.apply_hide_hud()
	shader_wide_enabled = false
	shader_mod.apply_viewport_size()
	shader_preset = 0
	shader_save()

func shader_save():
	var cfg: = ConfigFile.new()
	cfg.load(SHADER_CONFIG_PATH)
	cfg.set_value("shader", "shader_enabled", shader_enabled)
	cfg.set_value("shader", "hue", shader_hue)
	cfg.set_value("shader", "saturation", shader_saturation)
	cfg.set_value("shader", "energy", shader_energy)
	cfg.set_value("shader", "tonemap_mode", shader_tonemap_mode)
	cfg.set_value("shader", "posterization", shader_posterization_enabled)
	cfg.set_value("shader", "shadow_opacity", shader_shadow)
	cfg.set_value("shader", "glow", shader_glow_enabled)
	cfg.set_value("shader", "fog", shader_fog_enabled)
	cfg.set_value("shader", "volumetric_fog", shader_volume_fog_enabled)
	cfg.set_value("video", "hud", shader_hud_enabled)
	cfg.set_value("video", "wide_screen", shader_wide_enabled)
	cfg.save(SHADER_CONFIG_PATH)

func shader_load() -> void :
	var cfg: = ConfigFile.new()
	if cfg.load(SHADER_CONFIG_PATH) != OK: return
	shader_enabled = bool(cfg.get_value("shader", "shader_enabled", true))
	shader_hue = int(cfg.get_value("shader", "hue", 30))
	shader_saturation = float(cfg.get_value("shader", "saturation", 0.6))
	shader_energy = float(cfg.get_value("shader", "energy", 5.0))
	shader_tonemap_mode = int(cfg.get_value("shader", "tonemap_mode", 3))
	shader_posterization_enabled = bool(cfg.get_value("shader", "posterization", true))
	shader_shadow = float(cfg.get_value("shader", "shadow_opacity", 0.6))
	shader_glow_enabled = bool(cfg.get_value("shader", "glow", false))
	shader_fog_enabled = bool(cfg.get_value("shader", "fog", true))
	shader_volume_fog_enabled = bool(cfg.get_value("shader", "volumetric_fog", true))
	shader_hud_enabled = bool(cfg.get_value("shader", "hud", true))
	shader_wide_enabled = bool(cfg.get_value("shader", "wide_screen", false))
