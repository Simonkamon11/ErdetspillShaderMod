extends Node

const MOD_ID := "Monkamon-ErdetShader"

func _init() -> void:
	var game_manager_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/components/game_manager.gd")
	ModLoaderMod.install_script_extension(game_manager_path)
	var settings_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/scenes/ui/settings_panel.gd")
	ModLoaderMod.install_script_extension(settings_path)


var lighting_cycle_shader_path := load("res://mods-unpacked/Monkamon-ErdetShader/scripts/lighting_cycle.gd")
const WORLD_ENVIRONMENT_ORIGINAL_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/scenes/world_environment_original.tscn")
const WORLD_ENVIRONMENT_SHADER_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/scenes/world_environment_shader.tscn")
const LIGHT_SHADER_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/scenes/directional_light_shader.tscn")

var world_environment_shader: WorldEnvironment
var light_shader: DirectionalLight3D
var environment_original: Environment


var shader_enabled: bool = false
var shader_hue: int = 30
var shader_saturation: float = 0.6
var shader_energy: float = 5.0
var shader_tonemap_mode: int = 3
var shader_posterization_enabled: bool = true
var shader_shadow: float = 0.6
var shader_glow_enabled: bool = false
var shader_fog_enabled: bool = true
var shader_volume_fog_enabled: bool = false
var shader_hud_enabled: bool = true
var shader_wide_enabled: bool = false


var _button_delay: int = 0

var world
var in_world: bool = false


func _process(delta: float) -> void:
	_button_delay -= 1
	if Input.is_key_pressed(KEY_F2) && _button_delay <= 0:
		_button_delay = 10
		GameManager.apply_shader_hide_hud(!GameManager.shader_hud_enabled)
	world = get_tree().current_scene
	if !world: return
	if world.name != "World":
		in_world = false
		return
	if !in_world:
		world_environment_shader = WORLD_ENVIRONMENT_SHADER_PATH.instantiate()
		environment_original = WORLD_ENVIRONMENT_ORIGINAL_PATH.instantiate().environment
		light_shader = LIGHT_SHADER_PATH.instantiate()
	var light: DirectionalLight3D = world.get_node_or_null("Skybox/DirectionalLight3D")
	if light:
		light_shader.rotation_degrees.x = light.rotation_degrees.x
		light_shader.rotation_degrees.y = light.rotation_degrees.y
	
	apply_shader()
	apply_hue()
	apply_saturation()
	apply_energy()
	apply_tonemap_mode()
	apply_posterization()
	apply_shadow()
	apply_glow()
	apply_fog()
	apply_volume_fog()
	apply_hide_hud()
	apply_viewport_size()
	in_world = true

func apply_shader(force=false):
	if GameManager.shader_enabled == self.shader_enabled && in_world && !force: return
	if GameManager.shader_enabled:
		print_debug("Enabling shaders")
		var skybox: Node3D = world.get_node_or_null("Skybox")
		if !skybox:
			print_debug("Skybox not found")
			return
		var world_environment: WorldEnvironment = skybox.get_node_or_null("WorldEnvironment")
		if !world_environment:
			print_debug("WorldEnvironment not found")
			return
		var light: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3D")
		if !light:
			print_debug("DirectionalLight not found")
			return
		var has_light_shader: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3DShader")
		if !has_light_shader:
			light_shader.name = "DirectionalLight3DShader"
			skybox.add_child(light_shader)
		light_shader = skybox.get_node_or_null("DirectionalLight3DShader")
		var skyboxmesh: Node3D = world.get_node_or_null("NavigationRegion3D/skyboxmesh")
		if !skyboxmesh:
			print_debug("NavigationRegion3D/skyboxmesh not found")
			return
		var light_cycle: Node = world.get_node_or_null("World#LightingCycle")
		if !light_cycle:
			print_debug("LightCycle not found")
			return
		
		world_environment.environment = world_environment_shader.environment
		
		light.visible = false
		light_shader.visible = true
		
		skyboxmesh.visible = false
		light_cycle.set_script(lighting_cycle_shader_path)
		
		self.shader_enabled = true
		print_debug("Shader enabled")
	else:
		print_debug("Disabling shaders")
		var skybox: Node3D = world.get_node_or_null("Skybox")
		if !skybox:
			print_debug("Skybox not found")
			return
		var world_environment: WorldEnvironment = skybox.get_node_or_null("WorldEnvironment")
		if !world_environment:
			print_debug("WorldEnvironment not found")
			return
		var light: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3D")
		if !light:
			print_debug("DirectionalLight not found")
			return
		var has_light_shader: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3DShader")
		if !has_light_shader:
			light_shader.name = "DirectionalLight3DShader"
			skybox.add_child(light_shader)
		light_shader = skybox.get_node_or_null("DirectionalLight3DShader")
		var skyboxmesh: Node3D = world.get_node_or_null("NavigationRegion3D/skyboxmesh")
		if !skyboxmesh:
			print_debug("NavigationRegion3D/skyboxmesh not found")
			return
		var light_cycle: Node = world.get_node_or_null("World#LightingCycle")
		if !light_cycle:
			print_debug("LightCycle not found")
			return
		
		world_environment.environment = environment_original
		
		light_shader.visible = false
		light.visible = true
		
		skyboxmesh.visible = true
		
		self.shader_enabled = false
		print_debug("Shader disabled")


func apply_hue():
	if GameManager.shader_hue == self.shader_hue && in_world: return
	self.shader_hue = GameManager.shader_hue
	light_shader.light_color = Color.from_hsv(self.shader_hue/360.0, self.shader_saturation, 0.70)
	world_environment_shader.environment.fog_light_color = Color.from_hsv(self.shader_hue/360, self.shader_saturation, 0.78)
	apply_shader(true)

func apply_saturation():
	if GameManager.shader_saturation == self.shader_saturation && in_world: return
	self.shader_saturation = GameManager.shader_saturation
	light_shader.light_color = Color.from_hsv(self.shader_hue/360.0, self.shader_saturation, 0.63)
	world_environment_shader.environment.fog_light_color = Color.from_hsv(self.shader_hue/360, self.shader_saturation, 0.78)
	apply_shader(true)

func apply_energy():
	if GameManager.shader_energy == self.shader_energy && in_world: return
	self.shader_energy = GameManager.shader_energy
	light_shader.light_energy = self.shader_energy
	apply_shader(true)

func apply_tonemap_mode():
	if GameManager.shader_tonemap_mode == self.shader_tonemap_mode && in_world: return
	self.shader_tonemap_mode = GameManager.shader_tonemap_mode
	world_environment_shader.environment.tonemap_mode = self.shader_tonemap_mode
	apply_shader(true)

func apply_posterization():
	if GameManager.shader_posterization_enabled == self.shader_posterization_enabled && in_world: return
	self.shader_posterization_enabled = GameManager.shader_posterization_enabled
	var filter = world.get_node_or_null("PSXFilter")
	if !filter:
		print_debug("PSXFilter not found")
		return
	filter.visible = self.shader_posterization_enabled

func apply_shadow():
	if GameManager.shader_shadow == self.shader_shadow && in_world: return
	self.shader_shadow = GameManager.shader_shadow
	light_shader.shadow_opacity = self.shader_shadow
	apply_shader(true)

func apply_glow():
	if GameManager.shader_glow_enabled == self.shader_glow_enabled && in_world: return
	self.shader_glow_enabled = GameManager.shader_glow_enabled
	world_environment_shader.environment.glow_enabled = self.shader_glow_enabled
	apply_shader(true)

func apply_fog():
	if GameManager.shader_fog_enabled == self.shader_fog_enabled && in_world: return
	self.shader_fog_enabled = GameManager.shader_fog_enabled
	world_environment_shader.environment.fog_enabled = self.shader_fog_enabled
	apply_shader(true)

func apply_volume_fog():
	if GameManager.shader_volume_fog_enabled == self.shader_volume_fog_enabled && in_world: return
	self.shader_volume_fog_enabled = GameManager.shader_volume_fog_enabled
	world_environment_shader.environment.volumetric_fog_enabled = self.shader_volume_fog_enabled
	apply_shader(true)

func apply_hide_hud():
	if GameManager.shader_hud_enabled == self.shader_hud_enabled && in_world: return
	self.shader_hud_enabled = GameManager.shader_hud_enabled
	var item_notif = world.get_node_or_null("ItemNotification")
	if !item_notif:
		print_debug("ItemNotification not found")
		return 
	var player = world.get_node_or_null("NavigationRegion3D/PlayerCharacter")
	if !player:
		print_debug("PlayerCharacter not found")
		return
	var hud = player.get_node_or_null("HUD")
	if !hud:
		print_debug("HUD not found")
		return
	var quest_hud = player.get_node_or_null("QuestHud")
	if !quest_hud:
		print_debug("QuestHud not found")
		return
	item_notif.visible = self.shader_hud_enabled
	hud.visible = self.shader_hud_enabled
	quest_hud.visible = self.shader_hud_enabled

func apply_viewport_size():
	if GameManager.shader_wide_enabled == self.shader_wide_enabled && in_world: return
	self.shader_wide_enabled = GameManager.shader_wide_enabled
	if self.shader_wide_enabled:
		get_window().content_scale_size = Vector2i(1920, 1080)
		get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT
	else:
		get_window().content_scale_size = Vector2i(640, 480)
		get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
