extends "res://components/game_manager.gd"

var shader_enabled: bool = true
var shader_hue: int = 30

func apply_shader(enabled: bool):
	shader_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shader()

func apply_shader_hue(hue):
	shader_hue = hue
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_hue()
