extends "res://scenes/ui/settings_panel.gd"

''' Old shader settings
func _build_video_tab(page: VBoxContainer) -> void:
	super(page)
	_add_check(page, "Shader mod", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)
'''

func _build_settings_panel() -> void:
	super()
	_build_shader_tab(_add_tab_page("Shader"))

func _build_shader_tab(page: VBoxContainer) -> void:
	if GameManager == null:
		return
	
	_add_check(page, "Shader mod", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)
	_add_slider_row(page, "Hue", 0.0, 359.0, 5.0, GameManager.shader_hue, 
		func(v: float) -> String: return "%d" % int(v), 
		func(v: float) -> void : GameManager.apply_shader_hue(v)
	)
