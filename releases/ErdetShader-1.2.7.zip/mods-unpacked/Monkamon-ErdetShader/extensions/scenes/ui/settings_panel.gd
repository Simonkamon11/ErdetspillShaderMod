extends "res://scenes/ui/settings_panel.gd"

''' Old shader settings
func _build_video_tab(page: VBoxContainer) -> void:
	super(page)
	_add_check(page, "Shader mod", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)
'''

func _build_settings_panel() -> void:
	super()
	var prev_tab: = 0
	if _tabs != null and is_instance_valid(_tabs):
		prev_tab = _tabs.current_tab
	_build_shader_tab(_add_tab_page("Shader"))
	_tabs.current_tab = clampi(prev_tab, 0, _tabs.get_tab_count() - 1)

func _build_shader_tab(page: VBoxContainer) -> void:
	if GameManager == null:
		return
	
	_add_option_row(page, "Settings presets", ["Default", "Realism", "Scenic", "Authentic", "Horror"], 
		GameManager.shader_preset, 
		func(idx: int) -> void :
			GameManager.apply_shader_preset(idx)
	)
	_add_slider_row(page, "Hue", 0.0, 359.0, 5.0, GameManager.shader_hue, 
		func(v: float) -> String: return "%d" % int(v), 
		func(v: float) -> void : GameManager.apply_shader_hue(v)
	)
	_add_slider_row(page, "Saturation", 0.0, 1.0, 0.05, GameManager.shader_saturation, 
		func(v: float) -> String: return _fmt_percent(v), 
		func(v: float) -> void : GameManager.apply_shader_saturation(v)
	)
	_add_slider_row(page, "Energy", 0.0, 16.0, 0.2, GameManager.shader_energy, 
		func(v: float) -> String: return "%.1f" % v, 
		func(v: float) -> void : GameManager.apply_shader_energy(v)
	)
	_add_slider_row(page, "Shadow opacity", 0.0, 1.0, 0.1, GameManager.shader_shadow, 
		func(v: float) -> String: return _fmt_percent(v), 
		func(v: float) -> void : GameManager.apply_shader_shadow(v)
	)
	_add_option_row(page, "Tonemap mode", ["Linear", "Reinhard", "Filmic", "ACES", "AgX"], 
		GameManager.shader_tonemap_mode, 
		func(idx: int) -> void :
			GameManager.apply_shader_tonemap_mode(idx)
	)
	_add_check(page, "Glow", GameManager.shader_glow_enabled, func(on: bool) -> void :
		GameManager.apply_shader_glow(on)
	)
	_add_check(page, "Volumetric Fog", GameManager.shader_volume_fog_enabled, func(on: bool) -> void :
		GameManager.apply_shader_volume_fog(on)
	)
	_add_check(page, "Posterization", GameManager.shader_posterization_enabled, func(on: bool) -> void :
		GameManager.apply_shader_posterization(on)
	)
	_add_check(page, "Shader", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)

func _build_video_tab(page: VBoxContainer) -> void:
	super(page)
	_add_check(page, "16:9 Viewport (ErdetShader)", GameManager.shader_wide_enabled, func(on: bool) -> void :
		GameManager.apply_shader_viewport_size(on)
	)
	_add_check(page, "HUD (F2) (ErdetShader)", GameManager.shader_hud_enabled, func(on: bool) -> void :
		GameManager.apply_shader_hide_hud(on)
	)

func _on_reset_pressed() -> void:
	if GameManager:
		GameManager.shader_reset()
	super()
