extends "res://scenes/ui/settings_panel.gd"

func _build_video_tab(page: VBoxContainer) -> void:
	super(page)
	_add_check(page, "Shader mod", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)
