extends "res://components/game_manager.gd"

var shader_enabled: bool = true

func apply_shader(enabled: bool):
	shader_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shader()
