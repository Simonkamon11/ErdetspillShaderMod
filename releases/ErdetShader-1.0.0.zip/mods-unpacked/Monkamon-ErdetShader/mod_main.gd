extends Node

const MOD_ID := "Monkamon-ErdetShader"

func _init() -> void:
	var game_manager_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/components/game_manager.gd")
	ModLoaderMod.install_script_extension(game_manager_path)
	var settings_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/scenes/ui/settings_panel.gd")
	ModLoaderMod.install_script_extension(settings_path)


var lighting_cycle_original_path := load("res://scripts/lighting_cycle.gd")
var lighting_cycle_shader_path := load("res://mods-unpacked/Monkamon-ErdetShader/scripts/lighting_cycle.gd")
const WORLD_ENVIRONMENT_ORIGINAL_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/world_environment_original.tscn")
const WORLD_ENVIRONMENT_SHADER_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/world_environment_shader.tscn")
const LIGHT_ORIGINAL_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/directional_light_original.tscn")
const LIGHT_SHADER_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/directional_light_shader.tscn")

var shader_enabled: bool = false
var in_world: bool = false


func _process(delta: float) -> void:
	apply_shader()

func apply_shader():
	var world := get_tree().current_scene
	if !world: return
	if world.name != "World":
		in_world = false
		return
	if GameManager.shader_enabled == self.shader_enabled && in_world: return
	in_world = true
	if GameManager.shader_enabled:
		print_debug("Enabling shaders")
		var skybox: Node3D = world.get_node_or_null("Skybox")
		if !skybox:
			print_debug("Skybox not found")
			return
		var world_environment: WorldEnvironment = get_child_of_type("WorldEnvironment", skybox)
		if !world_environment:
			print_debug("WorldEnvironment not found")
			return
		var light: DirectionalLight3D = get_child_of_type("DirectionalLight3D", skybox)
		if !light:
			print_debug("DirectionalLight not found")
			return
		var skyboxmesh: Node3D = world.get_node_or_null("NavigationRegion3D/skyboxmesh")
		if !skyboxmesh:
			print_debug("NavigationRegion3D/skyboxmesh not found")
			return
		var light_cycle: Node = world.get_node_or_null("World#LightingCycle")
		if !light_cycle:
			print_debug("LightCycle not found")
			return
		print_debug("Everything found (Shader Mod)")
		
		world_environment.queue_free()
		var world_environment_new: WorldEnvironment = WORLD_ENVIRONMENT_SHADER_PATH.instantiate()
		skybox.add_child(world_environment_new)
		
		light.queue_free()
		var light_new: DirectionalLight3D = LIGHT_SHADER_PATH.instantiate()
		skybox.add_child(light_new)
		
		skyboxmesh.visible = false
		light_cycle.set_script(lighting_cycle_shader_path)
		
		self.shader_enabled = true
		print_debug("Shader enabled")
	else:
		print_debug("Disabling shaders")
		var skybox: Node3D = world.get_node_or_null("Skybox")
		if !skybox:
			print_debug("Skybox not found")
			return
		var world_environment: WorldEnvironment = get_child_of_type("WorldEnvironment", skybox)
		if !world_environment:
			print_debug("WorldEnvironment not found")
			return
		var light: DirectionalLight3D = get_child_of_type("DirectionalLight3D", skybox)
		if !light:
			print_debug("DirectionalLight not found")
			return
		var skyboxmesh: Node3D = world.get_node_or_null("NavigationRegion3D/skyboxmesh")
		if !skyboxmesh:
			print_debug("NavigationRegion3D/skyboxmesh not found")
			return
		var light_cycle: Node = world.get_node_or_null("World#LightingCycle")
		if !light_cycle:
			print_debug("LightCycle not found")
			return
		print_debug("Everything found (Shader Mod)")
		
		world_environment.queue_free()
		var world_environment_new: WorldEnvironment = WORLD_ENVIRONMENT_ORIGINAL_PATH.instantiate()
		skybox.add_child(world_environment_new)
		
		light.queue_free()
		var light_new: DirectionalLight3D = LIGHT_ORIGINAL_PATH.instantiate()
		skybox.add_child(light_new)
		
		skyboxmesh.visible = true
		light_cycle.set_script(lighting_cycle_original_path)
		
		self.shader_enabled = false
		print_debug("Shader disabled")


func get_child_of_type(type, parent):
	for child in parent.get_children():
		if child.is_class(type):
			return child
