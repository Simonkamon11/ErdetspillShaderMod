extends "res://scenes/ui/settings_panel.gd"

''' Old shader settings
func _build_video_tab(page: VBoxContainer) -> void:
	super(page)
	_add_check(page, "Shader mod", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)
'''

func _build_settings_panel() -> void:
	super()
	var prev_tab: = 0
	if _tabs != null and is_instance_valid(_tabs):
		prev_tab = _tabs.current_tab
	_build_shader_tab(_add_tab_page("Shader"))
	_tabs.current_tab = clampi(prev_tab, 0, _tabs.get_tab_count() - 1)

func _build_shader_tab(page: VBoxContainer) -> void:
	if GameManager == null:
		return
	
	_add_check(page, "Shader mod", GameManager.shader_enabled, func(on: bool) -> void :
		GameManager.apply_shader(on)
	)
	_add_slider_row(page, "Hue", 0.0, 359.0, 5.0, GameManager.shader_hue, 
		func(v: float) -> String: return "%d" % int(v), 
		func(v: float) -> void : GameManager.apply_shader_hue(v)
	)
	_add_slider_row(page, "Energy", 0.0, 16.0, 0.2, GameManager.shader_energy, 
		func(v: float) -> String: return "%.1f" % v, 
		func(v: float) -> void : GameManager.apply_shader_energy(v)
	)
	_add_option_row(page, "Tonemap mode", ["Linear", "Reinhard", "Filmic", "ACES", "AgX"], 
		GameManager.shader_tonemap_mode, 
		func(idx: int) -> void :
			GameManager.apply_tonemap_mode(idx)
	)


func _on_reset_pressed() -> void:
	GameManager.shader_reset()
	super()
