extends "res://components/game_manager.gd"

var shader_enabled: bool = true
var shader_hue: int = 30
var shader_energy: float = 5.0
var shader_tonemap_mode: int = 3

func apply_shader(enabled: bool):
	shader_enabled = enabled
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_shader()

func apply_shader_hue(hue):
	shader_hue = hue
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_hue()

func apply_shader_energy(erg):
	shader_energy = erg
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_energy()

func apply_tonemap_mode(idx):
	shader_tonemap_mode = idx
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	shader_mod.apply_tonemap_mode()


func shader_reset():
	var shader_mod := get_tree().root.find_child("Monkamon-ErdetShader", true, false)
	if !shader_mod: return
	
	shader_enabled = true
	shader_mod.apply_shader()
	shader_hue = 30
	shader_mod.apply_hue()
	shader_energy = 5.0
	shader_mod.apply_energy()
	shader_tonemap_mode = 3
	shader_mod.apply_tonemap_mode()
