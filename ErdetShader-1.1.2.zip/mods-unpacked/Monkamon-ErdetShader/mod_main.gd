extends Node

const MOD_ID := "Monkamon-ErdetShader"

func _init() -> void:
	var game_manager_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/components/game_manager.gd")
	ModLoaderMod.install_script_extension(game_manager_path)
	var settings_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/scenes/ui/settings_panel.gd")
	ModLoaderMod.install_script_extension(settings_path)


var lighting_cycle_original_path := load("res://scripts/lighting_cycle.gd")
var lighting_cycle_shader_path := load("res://mods-unpacked/Monkamon-ErdetShader/scripts/lighting_cycle.gd")
const WORLD_ENVIRONMENT_ORIGINAL_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/world_environment_original.tscn")
const WORLD_ENVIRONMENT_SHADER_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/world_environment_shader.tscn")
const LIGHT_SHADER_PATH := preload("res://mods-unpacked/Monkamon-ErdetShader/nodes/directional_light_shader.tscn")

var world_environment_shader: WorldEnvironment
var light_shader: DirectionalLight3D
var environment_original: Environment


var shader_enabled: bool = false
var shader_hue: int = 30
var shader_energy: float = 5.0
var shader_tonemap_mode: int = 3

var world
var in_world: bool = false


func _process(delta: float) -> void:
	world = get_tree().current_scene
	if !world: return
	if world.name != "World":
		in_world = false
		return
	if !in_world:
		world_environment_shader = WORLD_ENVIRONMENT_SHADER_PATH.instantiate()
		environment_original = WORLD_ENVIRONMENT_ORIGINAL_PATH.instantiate().environment
		light_shader = LIGHT_SHADER_PATH.instantiate()
	apply_shader()
	apply_hue()
	apply_energy()
	apply_tonemap_mode()
	in_world = true

func apply_shader(force=false):
	if GameManager.shader_enabled == self.shader_enabled && in_world && !force: return
	if GameManager.shader_enabled:
		print_debug("Enabling shaders")
		var skybox: Node3D = world.get_node_or_null("Skybox")
		if !skybox:
			print_debug("Skybox not found")
			return
		var world_environment: WorldEnvironment = skybox.get_node_or_null("WorldEnvironment")
		if !world_environment:
			print_debug("WorldEnvironment not found")
			return
		var light: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3D")
		if !light:
			print_debug("DirectionalLight not found")
			return
		var has_light_shader: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3DShader")
		if !has_light_shader:
			light_shader.name = "DirectionalLight3DShader"
			skybox.add_child(light_shader)
		light_shader = skybox.get_node_or_null("DirectionalLight3DShader")
		var skyboxmesh: Node3D = world.get_node_or_null("NavigationRegion3D/skyboxmesh")
		if !skyboxmesh:
			print_debug("NavigationRegion3D/skyboxmesh not found")
			return
		var light_cycle: Node = world.get_node_or_null("World#LightingCycle")
		if !light_cycle:
			print_debug("LightCycle not found")
			return
		print_debug("Everything found (Shader Mod)")
		
		world_environment.environment = world_environment_shader.environment
		
		light.visible = false
		light_shader.visible = true
		
		skyboxmesh.visible = false
		light_cycle.set_script(lighting_cycle_shader_path)
		
		self.shader_enabled = true
		print_debug("Shader enabled")
	else:
		print_debug("Disabling shaders")
		var skybox: Node3D = world.get_node_or_null("Skybox")
		if !skybox:
			print_debug("Skybox not found")
			return
		var world_environment: WorldEnvironment = skybox.get_node_or_null("WorldEnvironment")
		if !world_environment:
			print_debug("WorldEnvironment not found")
			return
		var light: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3D")
		if !light:
			print_debug("DirectionalLight not found")
			return
		var has_light_shader: DirectionalLight3D = skybox.get_node_or_null("DirectionalLight3DShader")
		if !has_light_shader:
			light_shader.name = "DirectionalLight3DShader"
			skybox.add_child(light_shader)
		light_shader = skybox.get_node_or_null("DirectionalLight3DShader")
		var skyboxmesh: Node3D = world.get_node_or_null("NavigationRegion3D/skyboxmesh")
		if !skyboxmesh:
			print_debug("NavigationRegion3D/skyboxmesh not found")
			return
		var light_cycle: Node = world.get_node_or_null("World#LightingCycle")
		if !light_cycle:
			print_debug("LightCycle not found")
			return
		print_debug("Everything found (Shader Mod)")
		
		world_environment.environment = environment_original
		
		light_shader.visible = false
		light.visible = true
		
		skyboxmesh.visible = true
		light_cycle.set_script(lighting_cycle_original_path)
		
		self.shader_enabled = false
		print_debug("Shader disabled")


func apply_hue():
	if GameManager.shader_hue == self.shader_hue && in_world: return
	self.shader_hue = GameManager.shader_hue
	light_shader.light_color = Color.from_hsv(self.shader_hue/360.0, 0.63, 0.63)
	world_environment_shader.environment.fog_light_color = Color.from_hsv(self.shader_hue/360, 0.78, 0.78)
	apply_shader(true)

func apply_energy():
	if GameManager.shader_energy == self.shader_energy && in_world: return
	self.shader_energy = GameManager.shader_energy
	light_shader.light_energy = self.shader_energy
	apply_shader(true)

func apply_tonemap_mode():
	if GameManager.shader_tonemap_mode == self.shader_tonemap_mode && in_world: return
	self.shader_tonemap_mode = GameManager.shader_tonemap_mode
	world_environment_shader.environment.tonemap_mode = self.shader_tonemap_mode
	apply_shader(true)
