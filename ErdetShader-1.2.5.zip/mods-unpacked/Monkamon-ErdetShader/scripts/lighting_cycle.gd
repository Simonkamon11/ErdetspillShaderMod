extends Node

@export var sun: DirectionalLight3D
@export var world_env: WorldEnvironment







var time_of_day: float = 0.35


func _ready() -> void :
	add_to_group("LightingCycle")
	if sun == null:
		sun = get_tree().get_first_node_in_group("SunLight") as DirectionalLight3D
	if sun == null:
		sun = _find_node_by_class(get_tree().root, "DirectionalLight3D") as DirectionalLight3D
	if sun != null and not sun.is_in_group("DirectionalLight"):
		sun.add_to_group("DirectionalLight")
	if world_env == null:
		world_env = get_tree().get_first_node_in_group("WorldEnvironment") as WorldEnvironment
	if world_env == null:
		world_env = _find_node_by_class(get_tree().root, "WorldEnvironment") as WorldEnvironment
	if GameManager.has_signal("day_changed"):
		GameManager.day_changed.connect(_on_day_changed)
	_apply_lighting(time_of_day)
	if GameManager.has_method("apply_shadows"):
		GameManager.apply_shadows(GameManager.shadows_enabled)


var _light_frame: int = 0


const NIGHT_HINT_TIME: = 0.82


var _flashlight_hint_shown: bool = false



const DAY_TIME_SCALE: = 0.75
const NIGHT_TIME_SCALE: = 1.8

func _process(delta: float) -> void :
	var day_duration: = GameManager.day_duration_seconds
	if day_duration > 0.0:
		var is_day: = time_of_day >= 0.25 and time_of_day < 0.75
		var time_scale: = DAY_TIME_SCALE if is_day else NIGHT_TIME_SCALE
		time_of_day += delta * time_scale / day_duration
		if time_of_day >= 1.0:
			time_of_day -= 1.0

	var is_dark: = time_of_day >= NIGHT_HINT_TIME and time_of_day < 1.0
	if is_dark and not _flashlight_hint_shown and QuestNotifier != null:
		_flashlight_hint_shown = true
		QuestNotifier.show_hint("Det er blitt mørkt — trykk V for lommelykt")
	_light_frame += 1
	if _light_frame >= 4:
		_light_frame = 0
		_apply_lighting(time_of_day)


func _on_day_changed(_new_day: int) -> void :
	time_of_day = 0.25
	_apply_lighting(time_of_day)


func _apply_lighting(t: float) -> void :
	if sun == null or world_env == null:
		return


	var sun_angle: = (t - 0.25) * 360.0
	var sun_x: = -90.0 + cos(deg_to_rad(sun_angle)) * 70.0
	sun_x = clamp(sun_x, -180.0, 0.0)
	sun.rotation_degrees.x = sun_x
	sun.rotation_degrees.y = sin(deg_to_rad(sun_angle)) * 45.0


func _find_node_by_class(node: Node, class_name_str: String) -> Node:
	if node.get_class() == class_name_str:
		return node
	for child in node.get_children():
		var found: = _find_node_by_class(child, class_name_str)
		if found:
			return found
	return null
